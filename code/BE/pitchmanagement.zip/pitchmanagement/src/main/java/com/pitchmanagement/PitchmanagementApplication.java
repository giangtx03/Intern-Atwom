package com.pitchmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PitchmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PitchmanagementApplication.class, args);
	}

}
