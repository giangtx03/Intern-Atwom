package com.pitchmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PitchmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
